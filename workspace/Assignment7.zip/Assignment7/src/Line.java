import java.util.*;
import javax.swing.*;
import java.awt.*;


public class Line {
	private int x1,x2,y1,y2;
	private Color color;
	private Point ptStart,ptEnd;
	
	
	public Line(int px1, int py1, int px2, int py2, Color pcolor) // constructor that sets the color of the line as well as the coordinates
	{
		x1 = px1;
		x2 = px2;
		y1 = py1;
		y2 = py2;
		color = pcolor;
		
	}
	
	public void draw(Graphics page)
	{
		page.setColor(color);// insert user color
		page.drawLine(x1, y1, x2, y2);
         
	}
}
